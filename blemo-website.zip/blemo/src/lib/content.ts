// Education content (PRD §6.6). In production this moves to a headless CMS;
// the shape below mirrors the `content` table in the System Design doc.

export interface Article {
  slug: string;
  title: string;
  segmentTag: string;
  formula: "bolt" | "bloom" | "balance";
  excerpt: string;
  body: string[]; // paragraphs
}

export const ARTICLES: Article[] = [
  {
    slug: "why-mens-acne-needs-a-different-formula",
    title: "Why men's acne needs a different formula",
    segmentTag: "Men · 16–40",
    formula: "bolt",
    excerpt: "Double the oil, thicker skin, daily razor abrasion. Here's why the pink-bottle stuff was never going to work.",
    body: [
      "Male skin runs on higher androgen levels, which push sebaceous glands to produce significantly more oil than female skin — and keep producing it well into the 30s. That extra oil is exactly what acne bacteria feed on.",
      "Male skin is also structurally thicker, which means actives dosed for 'all skin types' often can't clean deeply enough to matter. And then there's shaving: a daily micro-abrasion event that spreads bacteria across the jaw and neck.",
      "A formula built for this reality biases hard toward deep cleansing — a full 2% salicylic acid to get into pores, zinc PCA to regulate oil at the source — then adds niacinamide so the barrier and post-shave skin don't pay the price.",
      "That's Bolt. If you've been borrowing a generic solution and wondering why it's slow, the answer usually isn't your discipline. It's the formula's assumptions.",
    ],
  },
  {
    slug: "teen-skin-is-not-small-adult-skin",
    title: "Teen skin is not small adult skin",
    segmentTag: "Women · 14–22",
    formula: "bloom",
    excerpt: "Puberty acne is hormonal flux on a barrier that's still under construction. Harsh adult actives cause the rebound breakouts.",
    body: [
      "Between 14 and 22, hormone levels aren't just high — they swing. Each swing changes oil production faster than skin can adapt, which is why teen breakouts feel so unpredictable.",
      "At the same time, the skin barrier is still maturing. Aggressive adult-strength acids strip it, the skin over-produces oil to compensate, and you get the classic rebound: two new spots for every one you dried out.",
      "Bloom leads with prevention and gentleness: azelaic acid at a teen-appropriate 5%, a PHA complex that exfoliates without the sting, and centella to calm what's already flared.",
      "The goal at this age isn't scorched earth. It's teaching skin a routine it can keep — which is also why Bloom is the formula we most recommend starting at 250 ml.",
    ],
  },
  {
    slug: "adult-acne-follows-your-cycle",
    title: "Adult acne follows your cycle, not your teens",
    segmentTag: "Women · 22–40",
    formula: "balance",
    excerpt: "Jawline spots that flare monthly are a different condition from teen acne — and teen products actively make them worse.",
    body: [
      "If your breakouts cluster along the jawline and chin and arrive on a roughly monthly schedule, you're looking at hormonal adult acne — one of the most common and most mistreated skin conditions in women over 22.",
      "The mistake is reaching for the products that worked (or didn't) at 16. Adult skin has lower oil, a thinner barrier, and two extra concerns teen skin doesn't: post-spot marks and early ageing. Teen formulas over-strip it and leave marks behind.",
      "Balance pairs a moderate salicylic-azelaic duo for the cyclical flares with bakuchiol — a retinol-alternative gentle enough for monthly use — to fade marks, and a ceramide trio to keep the barrier out of the fight.",
      "Treat the spots, respect the skin they're on. That's the whole philosophy.",
    ],
  },
];
