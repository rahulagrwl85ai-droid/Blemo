"use client";

// Cart + segment theme, persisted in localStorage. In production this pairs
// with a server-side cart; prices are always re-validated server-side at
// order creation (see /api/orders), so the client cart is untrusted UI state.

import React, { createContext, useContext, useEffect, useState } from "react";
import { FormulaCode, SizeMl } from "./catalog";

export interface CartLine {
  formula: FormulaCode;
  sizeMl: SizeMl;
  qty: number;
  subscription: boolean;
  refillOptIn: boolean;
}

interface CartCtx {
  lines: CartLine[];
  add: (line: CartLine) => void;
  remove: (i: number) => void;
  setQty: (i: number, qty: number) => void;
  clear: () => void;
  theme: string | null;
  setTheme: (t: FormulaCode | null) => void;
}

const Ctx = createContext<CartCtx | null>(null);

export function useCart(): CartCtx {
  const c = useContext(Ctx);
  if (!c) throw new Error("CartProvider missing");
  return c;
}

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [lines, setLines] = useState<CartLine[]>([]);
  const [theme, setThemeState] = useState<string | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem("blemo.cart");
      if (raw) setLines(JSON.parse(raw));
      const t = localStorage.getItem("blemo.theme");
      if (t) {
        setThemeState(t);
        document.documentElement.setAttribute("data-theme", t);
      }
    } catch {}
    setReady(true);
  }, []);

  useEffect(() => {
    if (ready) localStorage.setItem("blemo.cart", JSON.stringify(lines));
  }, [lines, ready]);

  const setTheme = (t: FormulaCode | null) => {
    setThemeState(t);
    if (t) {
      localStorage.setItem("blemo.theme", t);
      document.documentElement.setAttribute("data-theme", t);
    } else {
      localStorage.removeItem("blemo.theme");
      document.documentElement.removeAttribute("data-theme");
    }
  };

  const add = (line: CartLine) =>
    setLines((prev) => {
      const i = prev.findIndex(
        (l) =>
          l.formula === line.formula &&
          l.sizeMl === line.sizeMl &&
          l.subscription === line.subscription
      );
      if (i >= 0) {
        const next = [...prev];
        next[i] = { ...next[i], qty: next[i].qty + line.qty, refillOptIn: line.refillOptIn };
        return next;
      }
      return [...prev, line];
    });

  return (
    <Ctx.Provider
      value={{
        lines,
        add,
        remove: (i) => setLines((p) => p.filter((_, j) => j !== i)),
        setQty: (i, qty) =>
          setLines((p) => p.map((l, j) => (j === i ? { ...l, qty: Math.max(1, qty) } : l))),
        clear: () => setLines([]),
        theme,
        setTheme,
      }}
    >
      {children}
    </Ctx.Provider>
  );
}
