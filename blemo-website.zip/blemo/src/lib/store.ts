// ─── Data store ──────────────────────────────────────────────────────────────
// Demo persistence: a JSON file with atomic writes. Mirrors the Postgres
// schema in the System Design doc (§5) so swapping to Prisma/Postgres is a
// mechanical change. NOT for production concurrency.

import { promises as fs } from "fs";
import path from "path";
import { ALL_SKUS, FormulaCode, SizeMl } from "./catalog";

export type OrderStatus =
  | "payment_pending"
  | "paid"
  | "packed"
  | "shipped"
  | "delivered"
  | "refund_requested"
  | "refunded"
  | "cancelled";

export interface OrderItem {
  skuCode: string;
  formula: FormulaCode;
  sizeMl: SizeMl;
  qty: number;
  unitPricePaise: number; // snapshot at purchase (invoice integrity)
  perMlPaise: number;
  subscription: boolean;
  refillOptIn: boolean;
}

export interface Order {
  id: string;
  createdAt: string;
  status: OrderStatus;
  customer: { name: string; phone: string; email?: string };
  address: { line1: string; city: string; state: string; pincode: string };
  paymentMethod: "upi" | "card" | "wallet" | "cod";
  items: OrderItem[];
  subtotalPaise: number;
  shippingPaise: number;
  totalPaise: number;
  refillReminderAt?: string; // depletion-engine output
  segment?: string;
}

export interface Review {
  id: string;
  formula: FormulaCode;
  segmentLabel: string;
  rating: number;
  name: string;
  text: string;
  weeks: number;
  status: "approved" | "pending";
  verified: boolean;
}

interface Db {
  orders: Order[];
  inventory: Record<string, number>; // skuCode -> on_hand
  reviews: Review[];
}

const DB_PATH = path.join(process.cwd(), "data", "db.json");

const SEED_REVIEWS: Review[] = [
  { id: "r1", formula: "bolt", segmentLabel: "Men · 16–40", rating: 5, name: "Arjun K.", text: "Third product I tried this year, first one made for oily skin like mine. Forehead cleared in about 5 weeks. The quiz explanation of why men's skin needs stronger cleansing convinced me.", weeks: 6, status: "approved", verified: true },
  { id: "r2", formula: "bolt", segmentLabel: "Men · 16–40", rating: 4, name: "Sameer D.", text: "Post-shave breakouts on my neck are mostly gone. Wish I'd started with the 500ml — reordered at the bigger size for the per-ml saving.", weeks: 9, status: "approved", verified: true },
  { id: "r3", formula: "bloom", segmentLabel: "Women · 14–22", rating: 5, name: "Ishita R.", text: "Everything else stung my skin. This one doesn't and my chin spots stopped multiplying within a month. My dermatologist aunt approved the ingredient list.", weeks: 5, status: "approved", verified: true },
  { id: "r4", formula: "bloom", segmentLabel: "Women · 14–22", rating: 5, name: "Naina S.", text: "First routine I've actually stuck to. The WhatsApp refill reminder came exactly when the bottle was running out, which felt a bit magical.", weeks: 14, status: "approved", verified: true },
  { id: "r5", formula: "balance", segmentLabel: "Women · 22–40", rating: 5, name: "Priya M.", text: "Jawline flare-ups every cycle since I turned 27. Teen products wrecked my skin barrier. Eight weeks on Balance and last month I had two small spots instead of a breakout. Marks are fading too.", weeks: 8, status: "approved", verified: true },
  { id: "r6", formula: "balance", segmentLabel: "Women · 22–40", rating: 4, name: "Deepika V.", text: "Took ~3 weeks to see movement, so be patient. The 15-day refund promise is why I risked it at all; ended up subscribing instead.", weeks: 12, status: "approved", verified: true },
];

function seed(): Db {
  const inventory: Record<string, number> = {};
  for (const s of ALL_SKUS) inventory[s.skuCode] = 120;
  return { orders: [], inventory, reviews: SEED_REVIEWS };
}

async function load(): Promise<Db> {
  try {
    const raw = await fs.readFile(DB_PATH, "utf8");
    return JSON.parse(raw) as Db;
  } catch {
    const db = seed();
    await save(db);
    return db;
  }
}

async function save(db: Db): Promise<void> {
  await fs.mkdir(path.dirname(DB_PATH), { recursive: true });
  const tmp = `${DB_PATH}.${process.pid}.${Date.now()}.${Math.random().toString(36).slice(2)}.tmp`;
  await fs.writeFile(tmp, JSON.stringify(db, null, 2), "utf8");
  await fs.rename(tmp, DB_PATH);
}

// Naive in-process mutex — fine for a demo, replaced by DB transactions in prod.
let lock: Promise<unknown> = Promise.resolve();
function withLock<T>(fn: (db: Db) => Promise<[Db, T]>): Promise<T> {
  const run = lock.then(async () => {
    const db = await load();
    const [next, result] = await fn(db);
    await save(next);
    return result;
  });
  lock = run.catch(() => {});
  return run;
}

export async function getDb(): Promise<Db> {
  return load();
}

export async function createOrder(order: Order): Promise<Order> {
  return withLock(async (db) => {
    // reserve/commit inventory
    for (const it of order.items) {
      const have = db.inventory[it.skuCode] ?? 0;
      if (have < it.qty) throw new Error(`Out of stock: ${it.skuCode}`);
    }
    for (const it of order.items) db.inventory[it.skuCode] -= it.qty;
    db.orders.unshift(order);
    return [db, order];
  });
}

export async function getOrder(id: string): Promise<Order | undefined> {
  const db = await load();
  return db.orders.find((o) => o.id === id);
}

export async function advanceOrder(id: string, status: OrderStatus): Promise<void> {
  await withLock(async (db) => {
    const o = db.orders.find((x) => x.id === id);
    if (o) o.status = status;
    return [db, undefined];
  });
}

export async function addReview(r: Review): Promise<void> {
  await withLock(async (db) => {
    db.reviews.unshift(r);
    return [db, undefined];
  });
}

export async function moderateReview(id: string, approve: boolean): Promise<void> {
  await withLock(async (db) => {
    const r = db.reviews.find((x) => x.id === id);
    if (r) r.status = approve ? "approved" : r.status;
    if (!approve) db.reviews = db.reviews.filter((x) => x.id !== id);
    return [db, undefined];
  });
}
