// ─── Catalog + Pricing engine ────────────────────────────────────────────────
// Single source of truth for formulas, SKUs and the ₹/ml ladder.
// Rule (System Design §6): base ₹3/ml at 250ml; each larger size is priced
// 20% lower per-ml than the size below it. Prices stored in paise.

export type Segment = "S1" | "S2" | "S3";
export type FormulaCode = "bolt" | "bloom" | "balance";
export type SizeMl = 250 | 500 | 750;

export const BASE_PER_ML_PAISE = 300; // ₹3.00/ml
export const STEP_DISCOUNT = 0.2;
export const SIZES: SizeMl[] = [250, 500, 750];
export const DAILY_USE_ML = 2; // depletion assumption (System Design §8)
export const REFILL_LEAD_DAYS = 8;

export interface Formula {
  code: FormulaCode;
  name: string;
  segment: Segment;
  segmentLabel: string;
  tagline: string;
  cause: string; // the education angle: why acne is different for this segment
  actives: { name: string; role: string }[];
  batchPrefix: string;
}

export interface Sku {
  skuCode: string;
  formula: FormulaCode;
  sizeMl: SizeMl;
  perMlPaise: number;
  pricePaise: number;
  savingsVsBasePct: number; // per-ml saving vs 250ml
  daysSupply: number;
}

export const FORMULAS: Formula[] = [
  {
    code: "bolt",
    name: "Blemo Bolt",
    segment: "S1",
    segmentLabel: "Men · 16–40",
    tagline: "Built for skin that runs hot.",
    cause:
      "Male skin produces up to double the sebum, is ~20% thicker, and takes daily abrasion from sweat and shaving. Generic formulas under-clean it — Bolt biases hard toward deep cleansing, then protects the barrier.",
    actives: [
      { name: "Salicylic acid 2%", role: "deep pore cleansing" },
      { name: "Zinc PCA", role: "sebum regulation" },
      { name: "Niacinamide 4%", role: "barrier + post-shave calm" },
    ],
    batchPrefix: "BLT",
  },
  {
    code: "bloom",
    name: "Blemo Bloom",
    segment: "S2",
    segmentLabel: "Women · 14–22",
    tagline: "Gentle on new skin, tough on new spots.",
    cause:
      "Teen and early-twenties acne is driven by hormonal flux on skin that's still developing its barrier. Harsh adult formulas cause rebound breakouts — Bloom leads with prevention and gentleness.",
    actives: [
      { name: "Azelaic acid 5%", role: "gentle spot clearing" },
      { name: "PHA complex", role: "mild exfoliation, no sting" },
      { name: "Centella asiatica", role: "soothes active spots" },
    ],
    batchPrefix: "BLM",
  },
  {
    code: "balance",
    name: "Blemo Balance",
    segment: "S3",
    segmentLabel: "Women · 22–40",
    tagline: "For acne that follows your cycle, not your teens.",
    cause:
      "Adult female acne is typically hormonal and cyclical — jawline spots that flare monthly, on skin that also cares about marks and early ageing. Teen formulas over-strip it — Balance treats spots while repairing the barrier and fading marks.",
    actives: [
      { name: "Salicylic acid 1% + azelaic 5%", role: "cycle-flare control" },
      { name: "Bakuchiol", role: "marks + texture, retinol-gentle" },
      { name: "Ceramide trio", role: "barrier repair" },
    ],
    batchPrefix: "BLN",
  },
];

export function perMlPaise(size: SizeMl): number {
  const idx = SIZES.indexOf(size);
  let p = BASE_PER_ML_PAISE;
  for (let i = 0; i < idx; i++) p = Math.round(p * (1 - STEP_DISCOUNT));
  return p;
}

export function buildSku(formula: FormulaCode, sizeMl: SizeMl): Sku {
  const pm = perMlPaise(sizeMl);
  const f = FORMULAS.find((x) => x.code === formula)!;
  return {
    skuCode: `${f.batchPrefix}-${sizeMl}`,
    formula,
    sizeMl,
    perMlPaise: pm,
    pricePaise: pm * sizeMl,
    savingsVsBasePct: Math.round((1 - pm / BASE_PER_ML_PAISE) * 100),
    daysSupply: Math.round(sizeMl / DAILY_USE_ML),
  };
}

export const ALL_SKUS: Sku[] = FORMULAS.flatMap((f) =>
  SIZES.map((s) => buildSku(f.code, s))
);

export function getFormula(code: string): Formula | undefined {
  return FORMULAS.find((f) => f.code === code);
}
export function getSku(skuCode: string): Sku | undefined {
  return ALL_SKUS.find((s) => s.skuCode === skuCode);
}

export function rupees(paise: number): string {
  return `₹${(paise / 100).toLocaleString("en-IN", { maximumFractionDigits: 2 })}`;
}
export function perMlLabel(paise: number): string {
  return `₹${(paise / 100).toFixed(2)}/ml`;
}

// ─── Depletion engine (System Design §8) ────────────────────────────────────
export function daysSupply(sizeMl: SizeMl): number {
  return Math.round(sizeMl / DAILY_USE_ML);
}
export function predictedEmptyAt(deliveredAt: Date, sizeMl: SizeMl): Date {
  const d = new Date(deliveredAt);
  d.setDate(d.getDate() + daysSupply(sizeMl) - REFILL_LEAD_DAYS);
  return d;
}
export function supplyLabel(sizeMl: SizeMl): string {
  const months = daysSupply(sizeMl) / 30;
  return months >= 11.5
    ? "~12 months"
    : `~${Math.round(months * 2) / 2} months`.replace(".0", "");
}
