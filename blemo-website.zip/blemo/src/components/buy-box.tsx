"use client";

import { useState } from "react";
import Link from "next/link";
import {
  FormulaCode, SIZES, SizeMl, buildSku, rupees, perMlLabel, supplyLabel, getFormula,
} from "@/lib/catalog";
import { useCart } from "@/lib/client";

export function BuyBox({ formulaCode }: { formulaCode: FormulaCode }) {
  const [size, setSize] = useState<SizeMl>(500);
  const [mode, setMode] = useState<"once" | "subscribe">("once");
  const [refill, setRefill] = useState(true);
  const [added, setAdded] = useState(false);
  const { add, setTheme } = useCart();
  const f = getFormula(formulaCode)!;
  const sku = buildSku(formulaCode, size);

  return (
    <div className="label-card p-5">
      <div className="font-mono-label text-[0.65rem] uppercase text-[var(--muted)]">
        Choose your size
      </div>
      <div className="mt-3 grid gap-2">
        {SIZES.map((s) => {
          const k = buildSku(formulaCode, s);
          const active = s === size;
          return (
            <button
              key={s}
              onClick={() => { setSize(s); setAdded(false); }}
              aria-pressed={active}
              className={`flex items-center justify-between border-[1.5px] p-3 text-left text-sm transition-colors ${
                active
                  ? "border-[var(--ink)] bg-[var(--accent-soft)]"
                  : "border-[var(--line)] bg-[var(--card)] hover:border-[var(--ink)]"
              }`}
            >
              <span>
                <span className="font-semibold">{s} ml</span>
                <span className="ml-2 text-[var(--muted)]">lasts {supplyLabel(s)}</span>
              </span>
              <span className="text-right">
                <span className="font-semibold">{rupees(k.pricePaise)}</span>
                <span className="font-mono-label ml-2 text-[0.62rem] text-[var(--muted)]">
                  {perMlLabel(k.perMlPaise)}
                </span>
                {k.savingsVsBasePct > 0 && (
                  <span className="font-mono-label ml-1.5 text-[0.62rem] text-[var(--accent)]">
                    −{k.savingsVsBasePct}%/ml
                  </span>
                )}
              </span>
            </button>
          );
        })}
      </div>

      <div className="label-rule mt-4 pt-4">
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => setMode("once")}
            aria-pressed={mode === "once"}
            className={`border-[1.5px] p-2.5 text-sm font-medium ${
              mode === "once" ? "border-[var(--ink)] bg-[var(--accent-soft)]" : "border-[var(--line)]"
            }`}
          >
            Buy once
          </button>
          <button
            onClick={() => setMode("subscribe")}
            aria-pressed={mode === "subscribe"}
            className={`border-[1.5px] p-2.5 text-sm font-medium ${
              mode === "subscribe" ? "border-[var(--ink)] bg-[var(--accent-soft)]" : "border-[var(--line)]"
            }`}
          >
            Subscribe
          </button>
        </div>

        {mode === "subscribe" ? (
          <p className="mt-3 text-xs text-[var(--muted)]">
            A fresh bottle ships automatically every <b>{supplyLabel(size)}</b> — timed to
            when this size runs out at typical use (2 ml/day). Pause, skip or cancel anytime
            from your account.
          </p>
        ) : (
          <label className="mt-3 flex cursor-pointer items-start gap-2 text-xs">
            <input
              type="checkbox"
              checked={refill}
              onChange={(e) => setRefill(e.target.checked)}
              className="mt-0.5 !w-auto"
            />
            <span>
              <b>Remind me on WhatsApp when I&rsquo;m running low.</b>{" "}
              <span className="text-[var(--muted)]">
                One message, about a week before your {size} ml runs out, with a 1-tap
                reorder link. No spam, opt out anytime.
              </span>
            </span>
          </label>
        )}
      </div>

      {!added ? (
        <button
          className="btn mt-5 w-full"
          onClick={() => {
            setTheme(formulaCode);
            add({
              formula: formulaCode,
              sizeMl: size,
              qty: 1,
              subscription: mode === "subscribe",
              refillOptIn: mode === "once" && refill,
            });
            setAdded(true);
          }}
        >
          {mode === "subscribe" ? "Subscribe" : "Add to cart"} — {rupees(sku.pricePaise)}
        </button>
      ) : (
        <div className="mt-5 grid gap-2">
          <Link href="/cart" className="btn w-full">Go to cart</Link>
          <button className="btn btn-ghost w-full" onClick={() => setAdded(false)}>
            Add another
          </button>
        </div>
      )}
      <p className="font-mono-label mt-3 text-center text-[0.62rem] uppercase text-[var(--muted)]">
        UPI · Cards · Wallets · COD · Free shipping over ₹999
      </p>
    </div>
  );
}
