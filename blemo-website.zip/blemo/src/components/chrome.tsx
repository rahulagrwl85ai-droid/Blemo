"use client";

import Link from "next/link";
import { useCart } from "@/lib/client";

export function Header() {
  const { lines, theme, setTheme } = useCart();
  const count = lines.reduce((n, l) => n + l.qty, 0);
  return (
    <header className="sticky top-0 z-40 border-b-[1.5px] border-[var(--ink)] bg-[var(--paper)]/95 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
        <Link href="/" className="display text-2xl tracking-tight">
          blemo<span className="text-[var(--accent)]">.</span>
        </Link>
        <nav className="flex items-center gap-4 text-sm font-medium sm:gap-6">
          <Link href="/quiz" className="hover:text-[var(--accent)]">Find my formula</Link>
          <Link href="/products" className="hidden hover:text-[var(--accent)] sm:block">Formulas</Link>
          <Link href="/learn" className="hidden hover:text-[var(--accent)] sm:block">Learn</Link>
          <Link href="/cart" className="btn !px-3 !py-1.5 text-xs">
            Cart{count > 0 ? ` (${count})` : ""}
          </Link>
        </nav>
      </div>
      {theme && (
        <div className="border-t border-[var(--line)] bg-[var(--accent-soft)]">
          <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-1.5">
            <span className="font-mono-label text-[0.65rem] uppercase">
              Site tuned to your formula: {theme}
            </span>
            <button onClick={() => setTheme(null)} className="font-mono-label text-[0.65rem] underline">
              reset
            </button>
          </div>
        </div>
      )}
    </header>
  );
}

export function Footer() {
  return (
    <footer className="mt-20 border-t-[1.5px] border-[var(--ink)] bg-[var(--skin-tint)]">
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-10 sm:grid-cols-3">
        <div>
          <div className="display text-xl">blemo<span className="text-[var(--accent)]">.</span></div>
          <p className="mt-2 max-w-xs text-sm text-[var(--muted)]">
            Acne treatment formulated for your age and gender — because the cause of your acne isn't generic.
          </p>
        </div>
        <div className="text-sm">
          <div className="font-mono-label mb-2 text-xs uppercase text-[var(--muted)]">Promise</div>
          <p>15-day full refund if it doesn't work for you. No questions beyond the one that helps us improve.</p>
        </div>
        <div className="text-sm">
          <div className="font-mono-label mb-2 text-xs uppercase text-[var(--muted)]">Demo notes</div>
          <p className="text-[var(--muted)]">
            Payments, WhatsApp and courier are simulated in this build. Admin at <code>/admin</code>.
          </p>
        </div>
      </div>
    </footer>
  );
}
