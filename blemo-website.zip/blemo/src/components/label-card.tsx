import { Formula, SIZES, buildSku, rupees, perMlLabel, supplyLabel } from "@/lib/catalog";
import Link from "next/link";

// The signature element: every formula is presented as a prescription-style
// label — segment code, actives as "composition", the ₹/ml ladder as a
// dosage table. It appears on home, quiz result and PDP.

export function LabelCard({ formula, compact = false }: { formula: Formula; compact?: boolean }) {
  return (
    <div className="label-card p-5" data-theme={formula.code}>
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="font-mono-label text-[0.65rem] uppercase text-[var(--muted)]">
            Formula {formula.segment} · {formula.segmentLabel}
          </div>
          <div className="display mt-1 text-2xl">{formula.name}</div>
        </div>
        <span className="chip">{formula.batchPrefix}</span>
      </div>
      <p className="mt-2 text-sm text-[var(--muted)]">{formula.tagline}</p>

      <div className="label-rule mt-4 pt-3">
        <div className="font-mono-label mb-2 text-[0.65rem] uppercase text-[var(--muted)]">
          Composition · why it's different
        </div>
        <ul className="space-y-1 text-sm">
          {formula.actives.map((a) => (
            <li key={a.name} className="flex justify-between gap-3">
              <span className="font-medium">{a.name}</span>
              <span className="text-right text-[var(--muted)]">{a.role}</span>
            </li>
          ))}
        </ul>
      </div>

      {!compact && (
        <div className="label-rule mt-4 pt-3">
          <PriceLadder formulaCode={formula.code} mini />
        </div>
      )}

      <Link href={`/products/${formula.code}`} className="btn mt-5 w-full">
        View {formula.name.split(" ")[1]}
      </Link>
    </div>
  );
}

export function PriceLadder({ formulaCode, mini = false }: { formulaCode: Formula["code"]; mini?: boolean }) {
  return (
    <table className="w-full text-sm">
      <thead>
        <tr className="font-mono-label text-[0.62rem] uppercase text-[var(--muted)]">
          <th className="pb-1 text-left font-normal">Size</th>
          <th className="pb-1 text-left font-normal">Per ml</th>
          <th className="pb-1 text-right font-normal">Price</th>
          {!mini && <th className="pb-1 text-right font-normal">Lasts</th>}
        </tr>
      </thead>
      <tbody>
        {SIZES.map((s) => {
          const sku = buildSku(formulaCode, s);
          return (
            <tr key={s} className="tick-row border-t border-[var(--line)]">
              <td className="py-1.5 font-medium">{s} ml</td>
              <td className="py-1.5">
                {perMlLabel(sku.perMlPaise)}
                {sku.savingsVsBasePct > 0 && (
                  <span className="ml-1.5 font-mono-label text-[0.62rem] text-[var(--accent)]">
                    −{sku.savingsVsBasePct}%
                  </span>
                )}
              </td>
              <td className="py-1.5 text-right font-semibold">{rupees(sku.pricePaise)}</td>
              {!mini && <td className="py-1.5 text-right text-[var(--muted)]">{supplyLabel(s)}</td>}
            </tr>
          );
        })}
      </tbody>
    </table>
  );
}
