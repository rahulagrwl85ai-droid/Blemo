// Admin / OMS / IMS (PRD §6.9). Demo build: no auth — production puts this
// behind role-based access. Server component + server actions.

import { revalidatePath } from "next/cache";
import { getDb, advanceOrder, moderateReview, OrderStatus } from "@/lib/store";
import { ALL_SKUS, getFormula, rupees } from "@/lib/catalog";

export const dynamic = "force-dynamic";

const NEXT_STATUS: Partial<Record<OrderStatus, OrderStatus>> = {
  payment_pending: "paid",
  paid: "packed",
  packed: "shipped",
  shipped: "delivered",
  refund_requested: "refunded",
};

async function advance(formData: FormData) {
  "use server";
  const id = String(formData.get("id"));
  const to = String(formData.get("to")) as OrderStatus;
  await advanceOrder(id, to);
  revalidatePath("/admin");
}

async function moderate(formData: FormData) {
  "use server";
  await moderateReview(String(formData.get("id")), formData.get("action") === "approve");
  revalidatePath("/admin");
}

export default async function Admin() {
  const db = await getDb();
  const pendingReviews = db.reviews.filter((r) => r.status === "pending");

  return (
    <div className="py-12">
      <div className="font-mono-label text-xs uppercase text-[var(--accent)]">Blemo ops</div>
      <h1 className="display mt-1 text-4xl">Orders · Inventory · Moderation</h1>

      <section className="mt-10">
        <h2 className="display text-2xl">Orders ({db.orders.length})</h2>
        <div className="mt-4 overflow-x-auto">
          <table className="w-full min-w-[640px] text-sm">
            <thead className="font-mono-label text-left text-[0.65rem] uppercase text-[var(--muted)]">
              <tr>
                <th className="p-2">Order</th><th className="p-2">Customer</th>
                <th className="p-2">Items</th><th className="p-2">Total</th>
                <th className="p-2">Pay</th><th className="p-2">Status</th>
                <th className="p-2">Refill due</th><th className="p-2"></th>
              </tr>
            </thead>
            <tbody>
              {db.orders.map((o) => {
                const next = NEXT_STATUS[o.status];
                return (
                  <tr key={o.id} className="border-t border-[var(--line)] align-top">
                    <td className="p-2 font-mono-label text-xs">{o.id}</td>
                    <td className="p-2">{o.customer.name}<br /><span className="text-[var(--muted)]">{o.address.pincode}</span></td>
                    <td className="p-2">
                      {o.items.map((it, i) => (
                        <div key={i}>
                          {getFormula(it.formula)!.name} {it.sizeMl}ml × {it.qty}
                          {it.subscription && <span className="chip ml-1 !text-[0.55rem]">sub</span>}
                        </div>
                      ))}
                    </td>
                    <td className="p-2 font-semibold">{rupees(o.totalPaise)}</td>
                    <td className="p-2 uppercase">{o.paymentMethod}</td>
                    <td className="p-2"><span className="chip">{o.status}</span></td>
                    <td className="p-2 text-[var(--muted)]">
                      {o.refillReminderAt ? new Date(o.refillReminderAt).toLocaleDateString("en-IN") : "—"}
                    </td>
                    <td className="p-2">
                      {next && (
                        <form action={advance}>
                          <input type="hidden" name="id" value={o.id} />
                          <input type="hidden" name="to" value={next} />
                          <button className="btn !px-2.5 !py-1 text-xs">→ {next}</button>
                        </form>
                      )}
                    </td>
                  </tr>
                );
              })}
              {db.orders.length === 0 && (
                <tr><td colSpan={8} className="p-4 text-[var(--muted)]">
                  No orders yet. Place one from the storefront to see the pipeline.
                </td></tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      <section className="mt-12">
        <h2 className="display text-2xl">Inventory (9 SKUs)</h2>
        <div className="mt-4 grid gap-3 sm:grid-cols-3">
          {ALL_SKUS.map((s) => {
            const onHand = db.inventory[s.skuCode] ?? 0;
            const low = onHand < 30;
            return (
              <div key={s.skuCode} className={`border-[1.5px] p-3 text-sm ${low ? "border-[var(--ink)] bg-[var(--accent-soft)]" : "border-[var(--line)] bg-[var(--card)]"}`}>
                <div className="font-mono-label text-[0.65rem] uppercase text-[var(--muted)]">{s.skuCode}</div>
                <div className="mt-1 flex items-baseline justify-between">
                  <span>{getFormula(s.formula)!.name} · {s.sizeMl} ml</span>
                  <span className="font-semibold">{onHand}{low && " ⚠"}</span>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      <section className="mt-12">
        <h2 className="display text-2xl">Review moderation ({pendingReviews.length} pending)</h2>
        <div className="mt-4 grid gap-3">
          {pendingReviews.map((r) => (
            <div key={r.id} className="label-card flex items-start justify-between gap-4 p-4 text-sm">
              <div>
                <span className="chip">{r.segmentLabel}</span> {"★".repeat(r.rating)}
                <p className="mt-2">{r.text}</p>
                <p className="font-mono-label mt-1 text-[0.65rem] uppercase text-[var(--muted)]">{r.name}</p>
              </div>
              <div className="flex shrink-0 gap-2">
                <form action={moderate}>
                  <input type="hidden" name="id" value={r.id} />
                  <input type="hidden" name="action" value="approve" />
                  <button className="btn !px-3 !py-1.5 text-xs">Approve</button>
                </form>
                <form action={moderate}>
                  <input type="hidden" name="id" value={r.id} />
                  <input type="hidden" name="action" value="reject" />
                  <button className="btn btn-ghost !px-3 !py-1.5 text-xs">Reject</button>
                </form>
              </div>
            </div>
          ))}
          {pendingReviews.length === 0 && (
            <p className="text-sm text-[var(--muted)]">Moderation queue is clear.</p>
          )}
        </div>
      </section>
    </div>
  );
}
