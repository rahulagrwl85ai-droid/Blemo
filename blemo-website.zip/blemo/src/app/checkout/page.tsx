"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useCart } from "@/lib/client";
import { buildSku, getFormula, rupees } from "@/lib/catalog";

const METHODS = [
  { v: "upi", label: "UPI" },
  { v: "card", label: "Card" },
  { v: "wallet", label: "Wallet" },
  { v: "cod", label: "Cash on delivery" },
] as const;

export default function Checkout() {
  const { lines, clear } = useCart();
  const router = useRouter();
  const [form, setForm] = useState({ name: "", phone: "", line1: "", city: "", state: "", pincode: "" });
  const [method, setMethod] = useState<string>("upi");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const subtotal = lines.reduce((n, l) => n + buildSku(l.formula, l.sizeMl).pricePaise * l.qty, 0);
  const shipping = subtotal >= 99900 || subtotal === 0 ? 0 : 4900;

  async function place() {
    setBusy(true); setError(null);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customer: { name: form.name, phone: form.phone },
          address: { line1: form.line1, city: form.city, state: form.state, pincode: form.pincode },
          paymentMethod: method,
          lines,
        }),
      });
      const data = await res.json();
      if (!data.ok) { setError(data.error); setBusy(false); return; }
      clear();
      router.push(`/orders/${data.orderId}`);
    } catch {
      setError("Couldn't reach the server. Check your connection and try again.");
      setBusy(false);
    }
  }

  if (lines.length === 0)
    return <div className="py-20 text-center text-[var(--muted)]">Your cart is empty.</div>;

  return (
    <div className="mx-auto max-w-2xl py-12">
      <h1 className="display text-4xl">Checkout</h1>
      <div className="mt-8 grid gap-3">
        <div className="grid gap-3 sm:grid-cols-2">
          <label className="text-sm">Full name
            <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Aarav Shah" />
          </label>
          <label className="text-sm">Mobile (10 digits)
            <input value={form.phone} inputMode="numeric" maxLength={10}
              onChange={(e) => setForm({ ...form, phone: e.target.value.replace(/\D/g, "") })} placeholder="9876543210" />
          </label>
        </div>
        <label className="text-sm">Address
          <input value={form.line1} onChange={(e) => setForm({ ...form, line1: e.target.value })} placeholder="Flat, street, area" />
        </label>
        <div className="grid gap-3 sm:grid-cols-3">
          <label className="text-sm">City
            <input value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
          </label>
          <label className="text-sm">State
            <input value={form.state} onChange={(e) => setForm({ ...form, state: e.target.value })} />
          </label>
          <label className="text-sm">Pincode
            <input value={form.pincode} inputMode="numeric" maxLength={6}
              onChange={(e) => setForm({ ...form, pincode: e.target.value.replace(/\D/g, "") })} />
          </label>
        </div>

        <div className="mt-2">
          <div className="font-mono-label mb-2 text-[0.65rem] uppercase text-[var(--muted)]">Pay with</div>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            {METHODS.map((m) => (
              <button key={m.v} onClick={() => setMethod(m.v)} aria-pressed={method === m.v}
                className={`border-[1.5px] p-2.5 text-sm font-medium ${
                  method === m.v ? "border-[var(--ink)] bg-[var(--accent-soft)]" : "border-[var(--line)]"
                }`}>
                {m.label}
              </button>
            ))}
          </div>
        </div>

        <div className="label-card mt-4 p-5 text-sm">
          {lines.map((l, i) => {
            const f = getFormula(l.formula)!;
            const sku = buildSku(l.formula, l.sizeMl);
            return (
              <div key={i} className="flex justify-between py-1">
                <span>{f.name} {l.sizeMl} ml × {l.qty}{l.subscription ? " (subscription)" : ""}</span>
                <span>{rupees(sku.pricePaise * l.qty)}</span>
              </div>
            );
          })}
          <div className="flex justify-between py-1"><span>Shipping</span><span>{shipping === 0 ? "Free" : rupees(shipping)}</span></div>
          <div className="label-rule mt-2 flex justify-between pt-2 text-base font-semibold">
            <span>Total</span><span>{rupees(subtotal + shipping)}</span>
          </div>
        </div>

        {error && (
          <div className="border-[1.5px] border-[var(--ink)] bg-[var(--accent-soft)] p-3 text-sm">{error}</div>
        )}
        <button className="btn mt-2 w-full" onClick={place} disabled={busy}>
          {busy ? "Placing order…" : method === "cod" ? "Place order — pay on delivery" : "Pay & place order"}
        </button>
        <p className="text-center text-xs text-[var(--muted)]">
          Demo build: payment succeeds instantly. Production wires Razorpay here.
        </p>
      </div>
    </div>
  );
}
