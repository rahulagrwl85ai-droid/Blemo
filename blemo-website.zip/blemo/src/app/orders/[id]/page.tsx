import { notFound } from "next/navigation";
import Link from "next/link";
import { getOrder } from "@/lib/store";
import { getFormula, rupees, supplyLabel } from "@/lib/catalog";

export default async function OrderPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const order = await getOrder(id);
  if (!order) notFound();
  const refillDate = order.refillReminderAt
    ? new Date(order.refillReminderAt).toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" })
    : null;
  const hasSub = order.items.some((i) => i.subscription);

  return (
    <div className="mx-auto max-w-xl py-14">
      <div className="font-mono-label text-xs uppercase text-[var(--accent)]">Order confirmed</div>
      <h1 className="display mt-2 text-4xl">Thanks, {order.customer.name.split(" ")[0]}.</h1>
      <p className="mt-2 text-[var(--muted)]">
        Order <b>{order.id}</b> · {order.paymentMethod === "cod" ? "pay on delivery" : "paid"} ·
        we&rsquo;ll WhatsApp you the tracking link once it ships.
      </p>

      <div className="label-card mt-6 p-5 text-sm">
        {order.items.map((it, i) => {
          const f = getFormula(it.formula)!;
          return (
            <div key={i} className="flex justify-between py-1">
              <span>{f.name} {it.sizeMl} ml × {it.qty} <span className="text-[var(--muted)]">(lasts {supplyLabel(it.sizeMl)})</span></span>
              <span>{rupees(it.unitPricePaise * it.qty)}</span>
            </div>
          );
        })}
        <div className="label-rule mt-2 flex justify-between pt-2 font-semibold">
          <span>Total</span><span>{rupees(order.totalPaise)}</span>
        </div>
      </div>

      {hasSub && (
        <div className="mt-4 border-[1.5px] border-[var(--ink)] bg-[var(--accent-soft)] p-4 text-sm">
          <b>Subscription active.</b> Your next bottle is timed to when this one runs out.
          Pause, skip or cancel anytime — no lock-in.
        </div>
      )}
      {refillDate && !hasSub && (
        <div className="mt-4 border-[1.5px] border-[var(--ink)] bg-[var(--accent-soft)] p-4 text-sm">
          <b>Refill reminder set.</b> We&rsquo;ll message you on WhatsApp around <b>{refillDate}</b> —
          about a week before this bottle runs out at typical use — with a 1-tap reorder link.
        </div>
      )}

      <div className="mt-6 border-[1.5px] border-[var(--line)] p-4 text-sm text-[var(--muted)]">
        <b className="text-[var(--ink)]">15-day promise:</b> not seeing results? Reply
        &ldquo;refund&rdquo; to any of our messages or request it here — full refund to your
        original payment method.
      </div>

      <Link href="/" className="btn mt-8">Back to home</Link>
    </div>
  );
}
