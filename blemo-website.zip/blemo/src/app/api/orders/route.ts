// POST /api/orders — the money path (System Design §9).
// The client cart is untrusted: prices are recomputed server-side from the
// pricing engine; inventory is checked and committed atomically.
// Razorpay integration is stubbed: `paymentMethod !== "cod"` is treated as an
// instantly-successful prepaid payment. Production: create a Razorpay order,
// confirm via signed webhook, only then mark paid.

import { NextRequest, NextResponse } from "next/server";
import { buildSku, getFormula, predictedEmptyAt, SizeMl, FormulaCode } from "@/lib/catalog";
import { createOrder, Order } from "@/lib/store";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { customer, address, paymentMethod, lines } = body ?? {};
    if (!customer?.name || !customer?.phone) throw new Error("Name and phone are required.");
    if (!/^\d{10}$/.test(customer.phone)) throw new Error("Enter a 10-digit mobile number.");
    if (!address?.line1 || !/^\d{6}$/.test(address?.pincode ?? "")) throw new Error("Enter a full address with a 6-digit pincode.");
    if (!["upi", "card", "wallet", "cod"].includes(paymentMethod)) throw new Error("Pick a payment method.");
    if (!Array.isArray(lines) || lines.length === 0) throw new Error("Cart is empty.");

    const items = lines.map((l: { formula: FormulaCode; sizeMl: SizeMl; qty: number; subscription: boolean; refillOptIn: boolean }) => {
      const f = getFormula(l.formula);
      if (!f) throw new Error("Unknown formula.");
      const sku = buildSku(l.formula, l.sizeMl); // server-side price, always
      return {
        skuCode: sku.skuCode, formula: l.formula, sizeMl: l.sizeMl,
        qty: Math.max(1, Math.min(10, Number(l.qty) || 1)),
        unitPricePaise: sku.pricePaise, perMlPaise: sku.perMlPaise,
        subscription: !!l.subscription, refillOptIn: !!l.refillOptIn,
      };
    });

    const subtotal = items.reduce((n, it) => n + it.unitPricePaise * it.qty, 0);
    const shipping = subtotal >= 99900 ? 0 : 4900;
    const wantsRefill = items.find((it) => it.refillOptIn);
    // Depletion engine: assume delivery ~4 days out, remind before empty.
    const deliveryEta = new Date(); deliveryEta.setDate(deliveryEta.getDate() + 4);

    const order: Order = {
      id: `BLM${Date.now().toString(36).toUpperCase()}`,
      createdAt: new Date().toISOString(),
      status: paymentMethod === "cod" ? "paid" : "paid", // stub: prepaid succeeds instantly
      customer, address, paymentMethod, items,
      subtotalPaise: subtotal, shippingPaise: shipping, totalPaise: subtotal + shipping,
      refillReminderAt: wantsRefill
        ? predictedEmptyAt(deliveryEta, wantsRefill.sizeMl).toISOString()
        : undefined,
    };

    const saved = await createOrder(order);
    return NextResponse.json({ ok: true, orderId: saved.id });
  } catch (e) {
    return NextResponse.json(
      { ok: false, error: e instanceof Error ? e.message : "Something went wrong." },
      { status: 400 }
    );
  }
}
