import type { Metadata } from "next";
import "./globals.css";
import { CartProvider } from "@/lib/client";
import { Header, Footer } from "@/components/chrome";

export const metadata: Metadata = {
  title: "Blemo — acne care formulated for your age & gender",
  description:
    "Generic acne products fight someone else's acne. Blemo matches a formula to your age and gender — Bolt, Bloom or Balance — in 250, 500 and 750 ml.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <CartProvider>
          <Header />
          <main className="mx-auto min-h-[70vh] max-w-6xl px-4">{children}</main>
          <Footer />
        </CartProvider>
      </body>
    </html>
  );
}
