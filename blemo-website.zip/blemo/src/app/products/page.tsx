import { FORMULAS } from "@/lib/catalog";
import { LabelCard } from "@/components/label-card";

export const metadata = { title: "The three formulas — Blemo" };

export default function Products() {
  return (
    <div className="py-12">
      <h1 className="display text-4xl">Three formulas. Pick the one made for you.</h1>
      <p className="mt-3 max-w-2xl text-[var(--muted)]">
        Same 15-day refund promise, same per-ml pricing ladder, different chemistry.
        Not sure which is yours? The 60-second quiz will tell you — and why.
      </p>
      <div className="mt-10 grid gap-6 md:grid-cols-3">
        {FORMULAS.map((f) => <LabelCard key={f.code} formula={f} />)}
      </div>
    </div>
  );
}
