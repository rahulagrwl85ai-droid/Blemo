import { notFound } from "next/navigation";
import { FORMULAS, getFormula } from "@/lib/catalog";
import { getDb } from "@/lib/store";
import { BuyBox } from "@/components/buy-box";
import { PriceLadder } from "@/components/label-card";

export function generateStaticParams() {
  return FORMULAS.map((f) => ({ formula: f.code }));
}

export default async function PDP({ params }: { params: Promise<{ formula: string }> }) {
  const { formula } = await params;
  const f = getFormula(formula);
  if (!f) notFound();
  const db = await getDb();
  const reviews = db.reviews.filter((r) => r.formula === f.code && r.status === "approved");
  const avg = reviews.length
    ? (reviews.reduce((n, r) => n + r.rating, 0) / reviews.length).toFixed(1)
    : null;

  return (
    <div className="py-12" data-theme={f.code}>
      <div className="grid gap-10 md:grid-cols-2">
        <div>
          <div className="font-mono-label text-xs uppercase text-[var(--accent)]">
            Formula {f.segment} · {f.segmentLabel}
          </div>
          <h1 className="display mt-2 text-5xl">{f.name}</h1>
          <p className="mt-3 text-lg text-[var(--muted)]">{f.tagline}</p>
          {avg && (
            <p className="font-mono-label mt-2 text-[0.7rem] uppercase text-[var(--muted)]">
              ★ {avg} · {reviews.length} verified reviews
            </p>
          )}

          <div className="label-card mt-6 p-5">
            <div className="font-mono-label mb-2 text-[0.65rem] uppercase text-[var(--muted)]">
              Why your acne is different
            </div>
            <p className="text-sm leading-relaxed">{f.cause}</p>
            <div className="label-rule mt-4 pt-3">
              <div className="font-mono-label mb-2 text-[0.65rem] uppercase text-[var(--muted)]">
                Composition
              </div>
              <ul className="space-y-1 text-sm">
                {f.actives.map((a) => (
                  <li key={a.name} className="flex justify-between gap-3">
                    <span className="font-medium">{a.name}</span>
                    <span className="text-right text-[var(--muted)]">{a.role}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="mt-6">
            <div className="font-mono-label mb-2 text-[0.65rem] uppercase text-[var(--muted)]">
              The per-ml ladder — how sizes are priced
            </div>
            <PriceLadder formulaCode={f.code} />
            <p className="mt-2 text-xs text-[var(--muted)]">
              Every larger size costs 20% less per ml than the one below it. No coupon games — the maths is the discount.
            </p>
          </div>
        </div>

        <div>
          <BuyBox formulaCode={f.code} />
          <div className="mt-6 border-[1.5px] border-[var(--ink)] bg-[var(--accent-soft)] p-4 text-sm">
            <span className="font-semibold">15-day promise:</span> if your skin isn&rsquo;t
            responding, request a full refund from your order page. No courier chase, no interrogation.
          </div>
        </div>
      </div>

      <section className="mt-16">
        <h2 className="display text-3xl">Reviews from your segment</h2>
        <p className="mt-1 text-sm text-[var(--muted)]">
          Only verified purchases. Before/after photo uploads are moderated before publishing.
        </p>
        <div className="mt-6 grid gap-5 md:grid-cols-2">
          {reviews.map((r) => (
            <figure key={r.id} className="label-card p-5">
              <div className="flex items-center justify-between">
                <span className="chip">{r.segmentLabel}</span>
                <span aria-label={`${r.rating} out of 5`}>{"★".repeat(r.rating)}</span>
              </div>
              <blockquote className="mt-3 text-sm leading-relaxed">{r.text}</blockquote>
              <figcaption className="font-mono-label mt-3 text-[0.65rem] uppercase text-[var(--muted)]">
                {r.name} · week {r.weeks} · verified purchase
              </figcaption>
            </figure>
          ))}
          {reviews.length === 0 && (
            <p className="text-sm text-[var(--muted)]">No reviews yet for this formula.</p>
          )}
        </div>
      </section>
    </div>
  );
}
