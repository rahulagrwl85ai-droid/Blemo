"use client";

import Link from "next/link";
import { useCart } from "@/lib/client";
import { buildSku, getFormula, rupees, supplyLabel } from "@/lib/catalog";

export default function CartPage() {
  const { lines, remove, setQty } = useCart();
  const subtotal = lines.reduce(
    (n, l) => n + buildSku(l.formula, l.sizeMl).pricePaise * l.qty, 0
  );
  const shipping = subtotal >= 99900 || subtotal === 0 ? 0 : 4900;

  if (lines.length === 0)
    return (
      <div className="mx-auto max-w-lg py-20 text-center">
        <h1 className="display text-3xl">Your cart is empty</h1>
        <p className="mt-3 text-[var(--muted)]">
          Start with the quiz — it finds your formula and explains why.
        </p>
        <Link href="/quiz" className="btn mt-6">Find my formula</Link>
      </div>
    );

  return (
    <div className="mx-auto max-w-2xl py-12">
      <h1 className="display text-4xl">Cart</h1>
      <div className="mt-8 grid gap-4">
        {lines.map((l, i) => {
          const f = getFormula(l.formula)!;
          const sku = buildSku(l.formula, l.sizeMl);
          return (
            <div key={i} className="label-card p-4" data-theme={l.formula}>
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="font-semibold">{f.name} · {l.sizeMl} ml</div>
                  <div className="font-mono-label mt-1 text-[0.65rem] uppercase text-[var(--muted)]">
                    {sku.skuCode} · lasts {supplyLabel(l.sizeMl)}
                    {l.subscription && " · subscription"}
                    {l.refillOptIn && " · whatsapp refill reminder"}
                  </div>
                </div>
                <div className="text-right font-semibold">{rupees(sku.pricePaise * l.qty)}</div>
              </div>
              <div className="mt-3 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <button className="btn btn-ghost !px-3 !py-1" onClick={() => setQty(i, l.qty - 1)}>−</button>
                  <span className="w-6 text-center text-sm">{l.qty}</span>
                  <button className="btn btn-ghost !px-3 !py-1" onClick={() => setQty(i, l.qty + 1)}>+</button>
                </div>
                <button className="text-sm underline" onClick={() => remove(i)}>Remove</button>
              </div>
            </div>
          );
        })}
      </div>
      <div className="label-card mt-6 p-5 text-sm">
        <div className="flex justify-between py-1"><span>Subtotal</span><span>{rupees(subtotal)}</span></div>
        <div className="flex justify-between py-1">
          <span>Shipping</span><span>{shipping === 0 ? "Free" : rupees(shipping)}</span>
        </div>
        <div className="label-rule mt-2 flex justify-between pt-2 text-base font-semibold">
          <span>Total</span><span>{rupees(subtotal + shipping)}</span>
        </div>
        <Link href="/checkout" className="btn mt-4 w-full">Checkout</Link>
      </div>
    </div>
  );
}
