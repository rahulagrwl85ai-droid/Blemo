import Link from "next/link";
import { FORMULAS } from "@/lib/catalog";
import { LabelCard } from "@/components/label-card";
import { getDb } from "@/lib/store";

export default async function Home() {
  const db = await getDb();
  const featured = db.reviews.filter((r) => r.status === "approved").slice(0, 3);

  return (
    <div>
      {/* Hero — the thesis */}
      <section className="grid items-center gap-10 py-14 md:grid-cols-2 md:py-20">
        <div>
          <div className="font-mono-label text-xs uppercase text-[var(--accent)]">
            One lotion. Three formulas. Zero guesswork.
          </div>
          <h1 className="display mt-4 text-5xl sm:text-6xl">
            Your acne has a cause.
            <br />
            Generic products
            <br />
            fight someone else&rsquo;s.
          </h1>
          <p className="mt-5 max-w-md text-lg text-[var(--muted)]">
            A 16-year-old boy, a 17-year-old girl and a 30-year-old woman are
            fighting different biology. Blemo matches the formula to yours —
            so you stop paying, in months and money, for skincare built for
            somebody else.
          </p>
          <div className="mt-7 flex flex-wrap gap-3">
            <Link href="/quiz" className="btn">Find my formula — 60 seconds</Link>
            <Link href="/products" className="btn btn-ghost">See all three</Link>
          </div>
          <p className="font-mono-label mt-4 text-[0.7rem] uppercase text-[var(--muted)]">
            15-day full refund · from ₹1.92/ml · India-wide COD
          </p>
        </div>

        {/* The signature label, hero-sized */}
        <div className="grid gap-4">
          <LabelCard formula={FORMULAS[2]} compact />
          <div className="grid grid-cols-2 gap-4">
            <MiniLabel code="bolt" title="Bolt" sub="Men 16–40" />
            <MiniLabel code="bloom" title="Bloom" sub="Women 14–22" />
          </div>
        </div>
      </section>

      {/* Why generic fails */}
      <section className="border-y-[1.5px] border-[var(--ink)] bg-[var(--skin-tint)] py-12">
        <div className="mx-auto max-w-4xl px-2">
          <h2 className="display text-3xl">Same spots. Different reasons.</h2>
          <div className="mt-8 grid gap-6 md:grid-cols-3">
            {FORMULAS.map((f) => (
              <div key={f.code} className="border-l-[3px] border-[var(--ink)] pl-4" data-theme={f.code}>
                <div className="font-mono-label text-[0.65rem] uppercase text-[var(--accent)]">
                  {f.segmentLabel}
                </div>
                <p className="mt-2 text-sm leading-relaxed">{f.cause}</p>
              </div>
            ))}
          </div>
          <p className="mt-8 text-sm text-[var(--muted)]">
            One generic formula can&rsquo;t bias three different ways at once. That&rsquo;s the
            whole reason Blemo is three formulas — not a marketing size chart.
          </p>
        </div>
      </section>

      {/* Formulas */}
      <section className="py-14">
        <h2 className="display text-3xl">The three formulas</h2>
        <p className="mt-2 text-[var(--muted)]">
          Same promise, different chemistry. Every size is priced by the ml — bigger bottles cost less per ml.
        </p>
        <div className="mt-8 grid gap-6 md:grid-cols-3">
          {FORMULAS.map((f) => (
            <LabelCard key={f.code} formula={f} />
          ))}
        </div>
      </section>

      {/* Social proof */}
      <section className="py-6">
        <h2 className="display text-3xl">From people it was actually made for</h2>
        <div className="mt-8 grid gap-6 md:grid-cols-3">
          {featured.map((r) => (
            <figure key={r.id} className="label-card p-5">
              <div className="flex items-center justify-between">
                <span className="chip">{r.segmentLabel}</span>
                <span aria-label={`${r.rating} out of 5 stars`}>{"★".repeat(r.rating)}</span>
              </div>
              <blockquote className="mt-3 text-sm leading-relaxed">{r.text}</blockquote>
              <figcaption className="font-mono-label mt-3 text-[0.65rem] uppercase text-[var(--muted)]">
                {r.name} · week {r.weeks} · verified purchase
              </figcaption>
            </figure>
          ))}
        </div>
      </section>

      {/* Refund promise */}
      <section className="my-14 border-[1.5px] border-[var(--ink)] bg-[var(--accent-soft)] p-8 text-center">
        <h2 className="display text-3xl">If it doesn&rsquo;t work, it&rsquo;s free.</h2>
        <p className="mx-auto mt-3 max-w-lg text-[var(--muted)]">
          Use it for up to 15 days. Not seeing what you hoped for? Full refund to your
          original payment method — request it from your order page in two taps.
        </p>
        <Link href="/quiz" className="btn mt-6">Start the 60-second quiz</Link>
      </section>
    </div>
  );
}

function MiniLabel({ code, title, sub }: { code: string; title: string; sub: string }) {
  return (
    <Link
      href={`/products/${code}`}
      data-theme={code}
      className="label-card block p-4 transition-transform hover:-translate-y-0.5"
    >
      <div className="font-mono-label text-[0.62rem] uppercase text-[var(--muted)]">{sub}</div>
      <div className="display mt-1 text-xl">
        {title}
        <span className="text-[var(--accent)]">.</span>
      </div>
    </Link>
  );
}
