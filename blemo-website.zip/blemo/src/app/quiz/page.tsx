"use client";

// Quiz → recommendation (System Design §7). Deterministic rules:
// gender+age → segment/formula; severity+commitment → suggested size.
// Result sets the site theme — the moment the site "becomes yours".

import { useState } from "react";
import Link from "next/link";
import {
  FORMULAS, FormulaCode, SizeMl, buildSku, rupees, perMlLabel, supplyLabel, getFormula,
} from "@/lib/catalog";
import { useCart } from "@/lib/client";

type Answers = {
  gender?: "male" | "female";
  age?: string;
  pattern?: string;
  severity?: "few" | "regular" | "persistent";
  commitment?: "trying" | "committed";
};

const AGE_BANDS = {
  male: ["16–20", "21–30", "31–40"],
  female: ["14–17", "18–22", "23–30", "31–40"],
};

function recommend(a: Answers): { formula: FormulaCode; size: SizeMl } | null {
  if (!a.gender || !a.age || !a.severity || !a.commitment) return null;
  let formula: FormulaCode;
  if (a.gender === "male") formula = "bolt";
  else formula = ["14–17", "18–22"].includes(a.age) ? "bloom" : "balance";
  // Size logic: default 250 (trial); 500 if committed or persistent; both → 500 still
  // (750 is positioned as the reorder size, not the first-order size).
  const size: SizeMl =
    a.commitment === "committed" || a.severity === "persistent" ? 500 : 250;
  return { formula, size };
}

export default function Quiz() {
  const [a, setA] = useState<Answers>({});
  const [step, setStep] = useState(0);
  const { add, setTheme } = useCart();
  const [added, setAdded] = useState(false);
  const rec = recommend(a);

  const steps = [
    {
      key: "gender",
      q: "Your acne story starts with hormones. Which set is writing yours?",
      note: "Androgen levels are the single biggest driver of sebum production — and they differ sharply by sex.",
      options: [
        { v: "male", label: "Male" },
        { v: "female", label: "Female" },
      ],
      set: (v: string) => setA({ gender: v as Answers["gender"] }),
    },
    {
      key: "age",
      q: "How old are you?",
      note:
        a.gender === "female"
          ? "Teen acne and adult female acne are different conditions — different triggers, different treatment bias."
          : "Male skin's oil production stays elevated for decades — the formula stays cleansing-biased across this range.",
      options: (a.gender ? AGE_BANDS[a.gender] : []).map((v) => ({ v, label: v })),
      set: (v: string) => setA((p) => ({ ...p, age: v })),
    },
    {
      key: "pattern",
      q: "Where do your spots mostly show up?",
      note: "Location is a clue to cause: T-zone points to oil, jawline points to hormonal cycling, neck to friction/shaving.",
      options: [
        { v: "tzone", label: "Forehead & nose (T-zone)" },
        { v: "jaw", label: "Jawline & chin" },
        { v: "cheeks", label: "Cheeks" },
        { v: "mixed", label: "A bit everywhere" },
      ],
      set: (v: string) => setA((p) => ({ ...p, pattern: v })),
    },
    {
      key: "severity",
      q: "Right now, your skin has…",
      note: "This sets your starting size, not your formula.",
      options: [
        { v: "few", label: "A few occasional spots" },
        { v: "regular", label: "Regular breakouts" },
        { v: "persistent", label: "Persistent, stubborn acne" },
      ],
      set: (v: string) => setA((p) => ({ ...p, severity: v as Answers["severity"] })),
    },
    {
      key: "commitment",
      q: "How do you want to start?",
      note: "Bigger bottles cost less per ml — but trying first is a perfectly good strategy. There's a 15-day refund either way.",
      options: [
        { v: "trying", label: "Let me try it first" },
        { v: "committed", label: "I'm in — best value from day one" },
      ],
      set: (v: string) => setA((p) => ({ ...p, commitment: v as Answers["commitment"] })),
    },
  ];

  if (rec && step >= steps.length) {
    const f = getFormula(rec.formula)!;
    const sku = buildSku(rec.formula, rec.size);
    return (
      <div className="mx-auto max-w-xl py-12" data-theme={f.code}>
        <div className="font-mono-label text-xs uppercase text-[var(--accent)]">
          Your match · formula {f.segment}
        </div>
        <h1 className="display mt-2 text-4xl">{f.name}</h1>
        <p className="mt-3 text-[var(--muted)]">{f.cause}</p>

        <div className="label-card mt-6 p-5">
          <div className="flex items-center justify-between">
            <span className="chip">{f.segmentLabel}</span>
            <span className="chip">{sku.skuCode}</span>
          </div>
          <div className="label-rule mt-4 pt-3 text-sm">
            <div className="flex justify-between py-1">
              <span>Recommended start</span>
              <span className="font-semibold">{rec.size} ml · lasts {supplyLabel(rec.size)}</span>
            </div>
            <div className="flex justify-between py-1">
              <span>Price</span>
              <span className="font-semibold">
                {rupees(sku.pricePaise)}{" "}
                <span className="font-mono-label text-[0.65rem] text-[var(--muted)]">
                  ({perMlLabel(sku.perMlPaise)})
                </span>
              </span>
            </div>
            {sku.savingsVsBasePct > 0 && (
              <div className="flex justify-between py-1 text-[var(--accent)]">
                <span>Per-ml saving vs 250 ml</span>
                <span className="font-semibold">−{sku.savingsVsBasePct}%</span>
              </div>
            )}
          </div>
          {!added ? (
            <button
              className="btn mt-5 w-full"
              onClick={() => {
                setTheme(f.code);
                add({ formula: f.code, sizeMl: rec.size, qty: 1, subscription: false, refillOptIn: true });
                setAdded(true);
              }}
            >
              Add {f.name} {rec.size} ml to cart
            </button>
          ) : (
            <div className="mt-5 grid gap-2">
              <Link href="/cart" className="btn w-full">Go to cart</Link>
              <Link href={`/products/${f.code}`} className="btn btn-ghost w-full">
                See sizes & full details
              </Link>
            </div>
          )}
        </div>

        <p className="mt-4 text-sm text-[var(--muted)]">
          Not what you expected?{" "}
          <button className="underline" onClick={() => { setA({}); setStep(0); setAdded(false); }}>
            Retake the quiz
          </button>{" "}
          or browse <Link href="/products" className="underline">all three formulas</Link>.
        </p>
      </div>
    );
  }

  const s = steps[step];
  return (
    <div className="mx-auto max-w-xl py-12">
      <div className="font-mono-label flex justify-between text-[0.65rem] uppercase text-[var(--muted)]">
        <span>Find my formula</span>
        <span>step {step + 1} / {steps.length}</span>
      </div>
      <div className="mt-2 h-1 w-full bg-[var(--line)]">
        <div
          className="h-1 bg-[var(--accent)] transition-all"
          style={{ width: `${(step / steps.length) * 100}%` }}
        />
      </div>
      <h1 className="display mt-8 text-3xl">{s.q}</h1>
      <p className="mt-2 text-sm text-[var(--muted)]">{s.note}</p>
      <div className="mt-6 grid gap-3">
        {s.options.map((o) => (
          <button
            key={o.v}
            className="btn btn-ghost justify-start text-left"
            onClick={() => { s.set(o.v); setStep(step + 1); }}
          >
            {o.label}
          </button>
        ))}
      </div>
      {step > 0 && (
        <button className="mt-6 text-sm underline" onClick={() => setStep(step - 1)}>
          ← back
        </button>
      )}
    </div>
  );
}
