import { notFound } from "next/navigation";
import Link from "next/link";
import { ARTICLES } from "@/lib/content";
import { getFormula } from "@/lib/catalog";

export function generateStaticParams() {
  return ARTICLES.map((a) => ({ slug: a.slug }));
}

export default async function ArticlePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const a = ARTICLES.find((x) => x.slug === slug);
  if (!a) notFound();
  const f = getFormula(a.formula)!;

  return (
    <article className="mx-auto max-w-2xl py-14" data-theme={a.formula}>
      <span className="chip">{a.segmentTag}</span>
      <h1 className="display mt-4 text-4xl">{a.title}</h1>
      <div className="mt-8 space-y-5 text-[1.02rem] leading-relaxed">
        {a.body.map((p, i) => <p key={i}>{p}</p>)}
      </div>
      <div className="label-card mt-10 p-5">
        <div className="font-mono-label text-[0.65rem] uppercase text-[var(--muted)]">
          The formula built for this
        </div>
        <div className="display mt-1 text-2xl">{f.name}</div>
        <p className="mt-1 text-sm text-[var(--muted)]">{f.tagline}</p>
        <div className="mt-4 flex gap-3">
          <Link href={`/products/${f.code}`} className="btn">View {f.name.split(" ")[1]}</Link>
          <Link href="/quiz" className="btn btn-ghost">Not sure? Take the quiz</Link>
        </div>
      </div>
    </article>
  );
}
