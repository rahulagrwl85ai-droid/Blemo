import Link from "next/link";
import { ARTICLES } from "@/lib/content";

export const metadata = { title: "Learn — Blemo" };

export default function Learn() {
  return (
    <div className="py-12">
      <h1 className="display text-4xl">Know your acne before you fight it</h1>
      <p className="mt-3 max-w-2xl text-[var(--muted)]">
        The science of why acne differs by age and gender — and why that should change what you buy.
      </p>
      <div className="mt-10 grid gap-6 md:grid-cols-3">
        {ARTICLES.map((a) => (
          <Link key={a.slug} href={`/learn/${a.slug}`} data-theme={a.formula}
            className="label-card block p-5 transition-transform hover:-translate-y-0.5">
            <span className="chip">{a.segmentTag}</span>
            <h2 className="display mt-3 text-xl">{a.title}</h2>
            <p className="mt-2 text-sm text-[var(--muted)]">{a.excerpt}</p>
            <span className="font-mono-label mt-4 block text-[0.65rem] uppercase text-[var(--accent)]">
              Read →
            </span>
          </Link>
        ))}
      </div>
    </div>
  );
}
